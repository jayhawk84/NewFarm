﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewFarm
{
    public class Animal
    {
        public string animalType;
        public string animalName = "Unnamed animal";
        public string animalColor;
        public string animalSays;
    }
}
